//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CatchScreen.rc
//
#define IDD_CATCHSCREEN_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_CURSOR1                     129
#define IDB_BITMAP1                     131
#define IDC_CURSOR2                     132
#define IDC_CURSOR3                     133
#define IDC_CURSOR4                     134
#define IDC_CURSOR5                     135
#define IDC_CURSOR6                     136
#define IDC_EDIT1                       1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
